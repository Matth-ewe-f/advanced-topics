To run this final project

1. Navigate to the Full-Stack-Foundations/Lesson-4/Final-Project directory inside the vagrant environment

2. run database_setup.py to create the database

3. run lotsofmenus.py to populate the database

4. run finalproject.py and navigate to localhost:5000 in your browser

